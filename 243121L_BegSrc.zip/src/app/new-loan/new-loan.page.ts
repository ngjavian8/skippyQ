import { Component } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { Item } from '../shared/item';
import { ItemService } from '../shared/item.service';
import { FirebaseLoanService } from '../shared/services/firebase-loan.service';

@Component({
  selector: 'app-new-loan',
  templateUrl: 'new-loan.page.html',
  styleUrls: ['new-loan.page.scss'],
  standalone: false,
})
export class NewLoanPage {
  items: Item[];

  constructor(
    private itemService: ItemService,
    private loanService: FirebaseLoanService,
    private toastController: ToastController
  ) {
    this.itemService.getAllAsync().subscribe(data => {
      this.items = data;
    });
  }

  submit() {
    this.loanService.addLoan(this.items).then(async (loan) => {
      const toast = await this.toastController.create({
        message: 'Loan created with ID ' + loan.id,
        duration: 2000,
        position: 'top',
        color: 'secondary'
      });

      await toast.present();
      this.itemService.resetQuantity();
    });
  }
}