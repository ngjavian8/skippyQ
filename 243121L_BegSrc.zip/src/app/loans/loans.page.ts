import { Component } from '@angular/core';
import { Loan } from '../shared/loan';
import { FirebaseLoanService } from '../shared/services/firebase-loan.service';

@Component({
  selector: 'app-loans',
  templateUrl: 'loans.page.html',
  styleUrls: ['loans.page.scss'],
  standalone: false,
})
export class LoansPage {
  loans: Loan[];

  constructor(private loanService: FirebaseLoanService) {
    this.loanService.getLoans().subscribe(data => {
      this.loans = data;
    });
  }
}