import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Productservice } from '../shared/services/productservice';
import { Product } from '../shared/models/product';
import { positiveNumber } from '../shared/services/positiveNumber.validator';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.page.html',
  styleUrls: ['./add-product.page.scss'],
  standalone: false,
})
export class AddProductPage implements OnInit {
  addProductForm: FormGroup;
  categories: string[] | undefined;
  submitted: boolean = false;

  constructor(private route: ActivatedRoute, private router: Router, private productService: Productservice) {
    this.categories = ['Main', 'Beverage', 'Dessert'];
    this.addProductForm = new FormGroup({
      name: new FormControl('', [Validators.required]),
      price: new FormControl(0, [positiveNumber]),
      category: new FormControl('Dessert'),
      vegetarian: new FormControl(true)
    });
  }

  ngOnInit() {
  }
  add() {
    this.submitted = true;
    if (this.addProductForm.valid) {
      const prod = new Product(
        this.addProductForm.value.name,
        this.addProductForm.value.price,
        "", // No image
        this.addProductForm.value.name); // Use name as id
      prod.category = this.addProductForm.value.category;
      prod.vegetarian = this.addProductForm.value.vegetarian;
      this.productService.add(prod);
      this.router.navigate(['tabs/tab2']);
    }
  }
}
