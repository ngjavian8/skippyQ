import { TestBed } from '@angular/core/testing';

import { FirebaseProduct } from './firebase-product.service';

describe('FirebaseProduct', () => {
  let service: FirebaseProduct;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirebaseProduct);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
