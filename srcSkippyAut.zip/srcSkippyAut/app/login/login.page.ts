import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { Auth } from '../shared/services/auth';



@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  loginError: string= "";

  constructor(private modalController: ModalController , private auth: Auth) {
    this.loginForm = new FormGroup({
      email: new FormControl(''),
      password: new FormControl('')
    });
  }

  ngOnInit() {
  }
  //Week7
//  login() {
//  this.modalController.dismiss();
//  }

login() {
  this.auth.login(
    this.loginForm.value.email, this.loginForm.value.password).then(
      user => this.modalController.dismiss()
    )
    .catch(
      error => this.loginError = error.message
    );
  }
}
