import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { Auth } from '../shared/services/auth';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
  standalone: false,
})
export class SignupPage implements OnInit {
    signupForm: FormGroup;
    signupError: string ="";

  constructor(private modalController: ModalController , private auth: Auth) { 
    this.signupForm = new FormGroup({
      email: new FormControl(''),
      password: new FormControl('')
    });
  }

  ngOnInit() {
  }
//   //Week7
//   signup() {
//   this.modalController.dismiss();
// }

signup() {
  this.auth.signup(
    this.signupForm.value.email, this.signupForm.value.password).then(
      user => this.modalController.dismiss()
    )
    .catch(
      error => this.signupError = error.message
    );
  }
}
