import { Component, OnInit } from '@angular/core';
import { Item } from '../shared/models/item';
import { FavService } from '../shared/services/fav.service';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  standalone: false
})
export class Tab4Page implements OnInit {

  favItems: Item[] = [];

  constructor(private favService: FavService) { }

  ngOnInit() {
    this.favItems = this.favService.getFavs();
  }
}
