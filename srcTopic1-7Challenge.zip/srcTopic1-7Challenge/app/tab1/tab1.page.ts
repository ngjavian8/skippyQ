import { Component } from '@angular/core';
import { Item } from '../shared/models/item';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: false
})
export class Tab1Page {

  item: Item[] = []

  constructor() {
    this.item = [
      new Item('f-electrolux-563', 999, 'assets/img/f-electrolux.jpg', 3),
      new Item('w-fisher-89', 1200, 'assets/img/w-fisher.jpg', 2),
      new Item('w-lg-107', 690, 'assets/img/w-lg.jpg', 1),
      new Item('f-techno-901', 680, 'assets/img/f-techno.jpg', 1),
      new Item('w-midea-6368', 578, 'assets/img/w-midea.jpg', 3),
      new Item('w-samsung-429', 900, 'assets/img/w-samsung.jpg', 2),
      new Item('f-panasonic-1864', 1328, 'assets/img/f-panasonic.jpg', 2),
    ];
  }
  getRatingArray(rating: number) {
    return Array(rating);
  }

}
