export class Item {
    model: string;
    price: number;
    picture: string;
    rating: number;
    icon: string;

    constructor(model: string, price: number, picture: string, rating: number, icon?: string) {
        this.model = model;
        this.price = price;
        this.picture = picture;
        this.rating = rating;
        this.icon = icon!;
    }
}