import { Injectable } from '@angular/core';
import { Item } from '../models/item';


@Injectable({
  providedIn: 'root',
})
export class ItemService {
  items: Item[] = [];
  constructor() {

    this.items = [
      new Item('Samsung smart LED TV', 1890, '', 2, 'heart-outline'),
      new Item('Sony full HD Internet TV', 1700, '', 2, 'heart-outline'),
      new Item('Sharp HD LED TV', 1600, '', 2, 'heart-outline'),
      new Item('Acer Intel Core i5', 999, '', 2, 'heart-outline'),
      new Item('Lenovo Flex Win 10', 1238, '', 2, 'heart-outline'),
      new Item('Apple M1 Chip', 1880, '', 2, 'heart-outline')
    ];

  }
  getItems(): Item[] {
    return this.items;
  }

}


