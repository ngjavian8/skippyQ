import { Injectable } from '@angular/core';
import { Item } from '../models/item';

@Injectable({
  providedIn: 'root'
})
export class FavService {

  private favItems: Item[] = [];

  constructor() { }

  getFavs(): Item[] {
    return this.favItems;
  }

  add(item: Item) {
    const exists = this.favItems.find(x => x.model === item.model);
    if (!exists) {
      this.favItems.push(item);
    }
  }

  remove(item: Item) {
    const index = this.favItems.findIndex(x => x.model === item.model);
    if (index >= 0) {
      this.favItems.splice(index, 1);
    }
  }
}