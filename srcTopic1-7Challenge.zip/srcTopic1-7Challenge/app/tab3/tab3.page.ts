import { Component } from '@angular/core';
import { ItemService } from '../shared/services/item.service';
import { Item } from '../shared/models/item';
import { FavService } from '../shared/services/fav.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'] ,
  standalone: false
})
export class Tab3Page {
  items: Item[] = [];

constructor(
    private itemService: ItemService,
    private favService: FavService
  ) { }

  ngOnInit() {
    this.items = this.itemService.getItems();
  }

  toggleFav(item: Item) {
    if (item.icon === 'heart') {
      item.icon = 'heart-outline';
      this.favService.remove(item);
    } else {
      item.icon = 'heart';
      this.favService.add(item);
    }
  }

}
