import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FridgeInfoPage } from './fridge-info.page';

describe('FridgeInfoPage', () => {
  let component: FridgeInfoPage;
  let fixture: ComponentFixture<FridgeInfoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FridgeInfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
