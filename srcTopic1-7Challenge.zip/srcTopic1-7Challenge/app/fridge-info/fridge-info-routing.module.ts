import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FridgeInfoPage } from './fridge-info.page';

const routes: Routes = [
  {
    path: '',
    component: FridgeInfoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FridgeInfoPageRoutingModule {}
