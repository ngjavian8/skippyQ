import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fridge-info',
  templateUrl: './fridge-info.page.html',
  styleUrls: ['./fridge-info.page.scss'],
  standalone: false
})
export class FridgeInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
