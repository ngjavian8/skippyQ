import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FridgeInfoPageRoutingModule } from './fridge-info-routing.module';

import { FridgeInfoPage } from './fridge-info.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FridgeInfoPageRoutingModule
  ],
  declarations: [FridgeInfoPage]
})
export class FridgeInfoPageModule {}
