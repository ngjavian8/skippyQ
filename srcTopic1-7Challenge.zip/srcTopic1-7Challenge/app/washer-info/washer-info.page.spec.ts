import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WasherInfoPage } from './washer-info.page';

describe('WasherInfoPage', () => {
  let component: WasherInfoPage;
  let fixture: ComponentFixture<WasherInfoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherInfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
