import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washer-info',
  templateUrl: './washer-info.page.html',
  styleUrls: ['./washer-info.page.scss'],
  standalone: false
})
export class WasherInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
