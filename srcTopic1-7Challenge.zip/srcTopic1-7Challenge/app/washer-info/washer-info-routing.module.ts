import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WasherInfoPage } from './washer-info.page';

const routes: Routes = [
  {
    path: '',
    component: WasherInfoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class WasherInfoPageRoutingModule {}
