import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
  standalone: false
})
export class DetailPage implements OnInit {

  model: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {
    // Read the model from the route parameter, e.g. /detail/f-electrolux-563
    this.model = this.route.snapshot.params['model'];
  }

  ngOnInit() { }

  moreInfo() {
    // If model starts with 'f', go to fridge-info page
    if (this.model.startsWith('f')) {
      this.router.navigate(['fridge-info']);
    }
    // If model starts with 'w', go to washer-info page
    else if (this.model.startsWith('w')) {
      this.router.navigate(['washer-info']);
    }
    // Optional: handle unknown models
    else {
      // For now, do nothing or navigate back if you like
      // this.router.navigate(['tabs/tab2']);
    }
  }
}